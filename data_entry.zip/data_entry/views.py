from django.shortcuts import render, redirect
from .forms import * 
from .models import *
from django.http import JsonResponse


# Create your views here.
def set_data_entry(request):
    form = AddressForm()
    context = {
        'form': form,
    }
    return render(request, 'data_entry/input_data.html', context)


def set_pengguna(request):
    list_pengguna = Pengguna.objects.all().order_by('-id')
    context = None
    form = PenggunaForm(None)
    email_p = None

    if request.method == "POST":
        form = PenggunaForm(request.POST)
        if form.is_valid():
            # Simpan ID pengguna pada saat user klik menu sign in
            email = form.cleaned_data['email']
            request.session['email'] = email
            request.session.modified = True
            form.save()
            list_pengguna = Pengguna.objects.all().order_by('-id')
            email_p = request.session['email']
            context = {
                'form': form,
                'list_pengguna': list_pengguna,
                'email_p': email_p,
            }
            return render(request, 'data_entry/input_data_1.html', context)
    else:
        context = {
            'form': form,
            'list_pengguna': list_pengguna,
        }
        return render(request, 'data_entry/input_data_1.html', context)


def view_pengguna(request):
    pass

def view_pengguna(request, id):
    try:
        pengguna = Pengguna.objects.get(pk=id)
        return render(request, 'data_entry/pengguna_detail.html', {'user_id': pengguna.id})
    except Pengguna.DoesNotExist:
        return JsonResponse({'error': 'User not found'}, status=404)

def get_pengguna_detail_api(request, user_id):
    try:
        pengguna = Pengguna.objects.get(pk=user_id)
        data = {
            'email': pengguna.email,
            'address_1': pengguna.address_1,
            'address_2': pengguna.address_2,
            'city': pengguna.city,
            'state': pengguna.state,
            'zip_code': pengguna.zip_code,
            'tanggal_join': pengguna.tanggal_join.strftime('%Y-%m-%d')  # Format date as string
        }
        return JsonResponse(data)
    except Pengguna.DoesNotExist:
        return JsonResponse({'error': 'User not found'},status=404)
    
def set_content(request):
    form = ContentForm()
    context = {}
    email = request.session.get('email')
    pengguna = None
    isi_tabel = None

    if email:
        try:
            pengguna = Pengguna.objects.get(email=email)
            isi_tabel = Content.objects.filter(author=pengguna)
            
            if request.method == 'POST':
                form = ContentForm(request.POST)
                if form.is_valid():
                    content = form.save(commit=False)
                    content.author = pengguna
                    content.save()
                    return redirect('data_entry:set_content')
            else:
                
                form = ContentForm(initial={'author': pengguna})
                
        except Pengguna.DoesNotExist:
            pass  

    context = {
        'form': form,
        'email': email,
        'pengguna': pengguna,
        'isi_tabel': isi_tabel,
    }
    return render(request, 'data_entry/create_content.html', context)

